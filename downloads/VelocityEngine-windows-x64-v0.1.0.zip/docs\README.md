# VELOCITY ENGINE

A project-driven 3D/2D game engine built with C++20, SDL3, bgfx (Direct3D 11),
Jolt, ImGui and GLM. This repository contains the engine libraries, a Unity-Hub
style launcher (accounts, projects, templates, installs), a parkour debugger
editor tool, and a scripted demo game — all wired into one green build →
test → smoke-run loop.

## Highlights

- **Kinematic parkour movement** (`MovementController`): walk/run/sprint accel
  curves, gravity, variable-height hold-jump, coyote time, jump buffering, air
  control, max fall speed, auto-step and ground snap. Deterministic at a fixed
  120 Hz step; every value is data-driven from `data/defaults.json`.
- **Jolt physics** (`PhysicsWorld`): rigid bodies, ray casts with observer-body
  filtering, ground probes, a kinematic capsule character, and the parkour
  course (floor / kerb / box) built as real bodies.
- **Project system**: `ProjectRegistry` catalogs game templates
  (`blank2d`, `blank3d`, `parkour3d`, `platformer2d`, `fps3d`), installable
  modules, and player projects. Demo and editor accept `--project <dir>`.
- **Hub launcher** (`velocity-hub.exe`): sign in / create a local account, then
  manage **Projects** (new-project wizard, open in the editor), **Templates**
  (browse + seed a project) and **Installs** (per-version modules such as
  Android/iOS/VR).
- **Accounts** (`AccountManager`): local sign-up/sign-in, PBKDF2-HMAC-SHA256
  password hashing, persistent accounts + session files.
- **Parkour debugger** (editor): in-world trail of recent positions (colored by
  grounded/airborne), velocity arrow, step-event ticks, leap span markers, plus
  an ImGui HUD with pause/step/reset, live movement tuning, and a "Parkour &
  Physics" panel (gravity, max step height, debug draw) persisted to the
  project.
- **Demo game** (headless): scripted parkour course — sprint, auto-step a 0.25 m
  kerb, hold-jump a 0.75 m box — logged step-by-step.
- **Automated tests**: 39 Catch2 test cases across core, config, math,
  movement, parkour debugger, physics, project registry and auth (207
  assertions, all green).

## Building

Requirements: CMake (3.31+), Ninja, MSVC (VS2022/2026 toolchain), a Windows
machine. Third-party dependencies (SDL3, bgfx/bx/bimg, GLM, nlohmann_json,
tinygltf, ImGui, ImGuizmo, Jolt, Catch2, stb, miniaudio) are pinned and fetched
into `ThirdParty/_fetchcache`.

```
scripts\configure.bat     # CMake + Ninja + MSVC environment, generates build\
scripts\build.bat         # incremental build (ninja)
```

## Running

Artifacts land in `build\bin`:

```
velocity-hub.exe           # launcher: sign in / create account, Projects/Templates/Installs
velocity-editor.exe        # parkour debugger (physics + trail + HUD + live tuning)
velocity-demo.exe          # headless scripted parkour course (autoquit after 4 s)
velocity-tests.exe         # Catch2 suite (~39 cases)
```

Smoke runs are scriptable:

```
velocity-editor.exe --autoquit=6000
velocity-editor.exe --project "My Game"
velocity-demo.exe  --project "My Game"
velocity-hub.exe   --smoke --autoquit=4000    # creates account + project headless
```

Apps honor `--autoquit=<ms>`, `--project=<dir>` and `VELOCITY_AUTOQUIT_MS` /
`VELOCITY_PROJECT` environment variables.

## Documentation

- `ARCHITECTURE.md` — module layout, runtime flow, movement model, debug pipeline.
- `ACCEPTANCE.md` — acceptance checklist (core + engine/Hub phase) with status.
- `DEVELOPMENT_STATUS.md` — build/test/run status snapshot and gotchas.

## Repository layout

```
VelocityEngine/
  cmake/            build helpers, shader pipeline (Shaders.cmake)
  scripts/          configure.bat, build.bat
  data/
    defaults.json   data-driven engine/movement values
    installs.json   module registry (Installs tab)
    templates/<id>/ game templates (template.json + seed level.json/movement.json)
    projects/       player projects (project.json + seeded content)
  Engine/
    Core/           Config, Log, Memory, Time, EventBus, Types
    Application/    SDL3 window + app loop
    Math/           glm-based helpers
    Project/        project registry (templates, modules, projects)
    Auth/           AccountManager (local accounts)
    Serialization/  JSON config/serialization
    Input/          keyboard / mouse / gamepad front-end
    Rendering/      Renderer (bgfx), ShaderLibrary, DebugDraw, ImGuiBackend, shaders/
    Physics/        Jolt-backed world, Course, CharacterController
    Gameplay/       MovementValues, MovementController, ParkourDebugger
    Assets/ Audio/ Animation/ ... (scaffolding)
  Tools/            ve_embed (shader blob embedding)
  Hub/              velocity-hub.exe (launcher)
  Editor/           velocity-editor.exe
  Game/DemoGame/    velocity-demo.exe
  Tests/            Catch2 suites
  ThirdParty/       pinned deps (+ _fetchcache cache)
```

## Roadmap (parkour-FPS → game engine)

1. Engine bootstrap + baseline (build/test/render/UI) — **done**
2. Movement pipeline: values, controller, unit tests — **done**
3. Parkour debugger: telemetry recorder, debug rendering, ImGui HUD — **done**
4. Demo game: scripted parkour course, data-driven logging — **done**
5. Documentation + acceptance tracking — **done**
6. Jolt physics: world, rigid bodies, ray casts, character — **done**
7. Project-driven engine: `Project`/`Auth` modules, `--project` in demo+editor,
   Parkour & Physics panel — **done**
8. Hub launcher: accounts gate, Projects/Templates/Installs, open-in-editor — **done**
9. Full 2D pipeline (orthographic render path + sprites) using the 2D templates — next
10. Cloud account sync, tilemap/level editor, FPS camera rig, GLTF/animation,
    audio, light AI