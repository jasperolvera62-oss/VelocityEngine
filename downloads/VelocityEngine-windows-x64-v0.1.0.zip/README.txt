VELOCITY ENGINE v0.1.0 (Windows x64)
=======================================

Quick start:
  1. Unzip this folder anywhere.
  2. Double-click velocity-hub.exe
  3. Create an account (or sign in), pick the 'Parkour 3D' template and press
     '+ new project'.
  4. The editor and demo are not bundled in this download. Build them locally
     from source or look for optional module downloads in the Installs tab
     in a future release.

App:
  velocity-hub.exe      launcher (Projects / Templates / Installs)

Movement and engine settings live in data\ *.json (defaults.json, installs.json,
templates\, projects\). Docs are in docs\.

-- The Velocity Engine team
