# VELOCITY ENGINE — Development Status

_Last updated: 2026-09-12_

## Build status

| Check                          | Result                                          |
| ------------------------------ | ----------------------------------------------- |
| Configure                      | OK (Ninja, MSVC VS2022, C++20)                  |
| Full build                     | **GREEN** (exit 0)                              |
| Unit tests (`velocity-tests`)  | **PASS** — 207 assertions, 39 test cases        |
| Demo smoke-run (`velocity-demo.exe`) | **PASS** — parkour course logged, exit 0    |
| Project demo (`--project`)     | **PASS** — loads level.json + movement overlay  |
| Editor smoke-run (`--autoquit=6000`) | **PASS** — parkour run grounded, exit 0     |
| Editor project smoke (`--project`) | **PASS** — grounded, clean shutdown          |
| Hub smoke (`--smoke --autoquit`) | **PASS** — account sign-in + project created   |

Smoke-run runtime log confirms the full render path initializes:

```
[ INFO][renderer] bgfx initialized (Direct3D 11, 1280x720, origin top-left, vsync)
[ INFO][shaders ] embedded shader index ready (14 blobs)
[ INFO][shaders ] linked program 'vs_imgui' + 'fs_imgui'
[ INFO][imgui   ] backend initialized (font 512x64)
```

Demo game (fixed-step, deterministic, data-driven):

```
sprint speed before jump: 9.50 m/s (target 9.50)
auto-stepped 0.25 m kerb (height while grounded 0.25 m), no jump used
jump cleared the 0.75 m box by 0.96 m (peak 1.71 m)
parkour run complete (479 steps):  peak height 1.71 m, peak speed 9.50 m/s
movement values: walk 4.0 run 6.5 sprint 9.5 gravity 20.0 jump 5.8 coyote 0.10s
```

Editor parkour debugger smoke-run:

```
linked program 'vs_line' + 'fs_line'
autoquit after 6000 ms
parkour: steps 718, peak 1.46 m, peak speed 9.50 m/s, distance 17.97 m, flights 1, air 13%
parkour: final (+0.00, 0.00, +13.97), state grounded
```

Hub smoke-run (exercises account + project creation):

```
[ INFO][hub] smoke: created and signed into account 'smoke'
[ INFO][hub] smoke: signed in=1  projects=1
[ INFO][hub] smoke: project ready: Velocity Smoke (3d)
[ INFO][hub] autoquit after 3000 ms
```

## Repository layout

```
VelocityEngine/
  cmake/            Deps.cmake, Shaders.cmake, velocity_add_library helpers, Runtime.cmake
  scripts/          configure.bat, build.bat (wrap CMake + Ninja + MSVC env)
  data/
    defaults.json           data-driven engine/movement values
    installs.json           module registry (Installs tab)
    templates/<id>/         game templates: blank2d, blank3d, parkour3d,
                            platformer2d, fps3d (template.json + level.json + movement.json)
    projects/               player projects (project.json + seeded level/movement) + accounts.json/session.json
  Engine/
    Core/           Config, Log, Memory (arena + object pool), Time, EventBus
    Application/    SDL3 window + application loop
    Math/           glm-based helpers (fwd header + inline helpers)
    Serialization/  JSON-backed config/system serialization
    Project/        project registry: templates, modules/installs, project create/load/save
    Auth/           AccountManager: local accounts, PBKDF2-HMAC-SHA256 hashing, session
    Input/          Keyboard / mouse / gamepad front-end (InputManager)
    Rendering/      Renderer (bgfx D3D11), ShaderLibrary (embedded blobs), Vertex, ImGuiBackend
    Shader/         shaders/ (GLSL - SC source), compiled via shaderc -> embedded
    Physics/        Jolt-backed world (bodies, ray cast with body filter), Course, CharacterController
    Gameplay/       MovementValues, MovementController (kinematic parkour movement),
                    ParkourDebugger (trail/flight/step-event telemetry, unit-tested)
    Assets/ Audio/ Animation/ Networking/ Logging/ Events/ Time/  (scaffolding)
  Tools/            ve_embed (embeds compiled shader binaries into a C++ TU)
  Editor/           velocity-editor.exe (window + ImGui runtime + parkour debugger + physics)
  Hub/              velocity-hub.exe (login, Projects/Templates/Installs launcher)
  Game/DemoGame/    velocity-demo.exe (game bootstrap + scripted parkour course)
  README.md, ARCHITECTURE.md, ACCEPTANCE.md (docs + acceptance list)
  Tests/            Catch2 suites: test_core, test_math, test_config, test_movement,
                    test_parkour_debugger, test_physics, test_project, test_auth
  ThirdParty/       SDL3 prebuilt, bgfx/bx/bimg pinned (commit 7e8bb58, 2026 API),
                    GLM, nlohmann_json, tinygltf, imgui, ImGuizmo, Jolt, Catch2, stb, miniaudio
```

## What works today

- **Build infrastructure**: CMake + Ninja with static-CRT MSVC; bgfx prebuilt via its embedded
  build (Debug/Release shaderc); FetchContent-pinned deps cached under `ThirdParty/_fetchcache`.
- **Core**: type aliases, config load/save, tiered logging (recursive-mutex safe), memory arena +
  object pool, frame-time accumulator, EventBus (subscribe/publish).
- **Math**: glm-backed helpers (`ve::math::`), AABB, quaternion helpers, projection, ray.
- **Input**: unified `InputManager` (keyboard, mouse move/button/scroll, gamepad open/close/
  button/axis) feeding SDL3 events from the window loop.
- **Rendering**: bgfx D3D11 device init on SDL3 HWND via swap-chain API, reset/back-buffer
  recreation, `ShaderLibrary` (14 embedded shaders), full-screen + mesh + line draw paths,
  ImGui backend (font atlas texture).
- **Physics**: Jolt-backed world (`PhysicsWorld`): rigid bodies (box/sphere), broadphase + narrow
  phase queries, `cast_ray` with an optional observer body filter, ground probe, kinematic
  `CharacterController` capsule, `build_parkour_course`. Uses `JobSystemSingleThreaded`
  (deterministic single-thread stepping).
- **Movement**: data-driven kinematic `MovementController` (walk/run/sprint accel curves, gravity,
  variable-height hold-jump, coyote time, jump buffering, air control, max fall speed, ground snap
  + auto-step, ceiling-safe landing) with unit tests and JSON tuning via `data/defaults.json`.
- **Parkour debugger**: `ParkourDebugger` telemetry recorder (position trail, state/speed timers,
  step-event log, flight/leap stats) + in-world `DebugDraw` trail/arrows/step ticks + ImGui HUD
  with pause/step/reset and live movement-value tuning.
- **Project system**: `ProjectRegistry` scans `data/projects` for player projects, catalogs
  `data/templates` and the installable module registry (`data/installs.json`), creates new
  projects from a template (seeds level.json/movement.json + project.json manifest) and persists
  module toggles.
- **Accounts**: local `AccountManager` — create/sign-in (username or email), sign out, persistent
  accounts.json + session.json, PBKDF2-HMAC-SHA256 password hashing (60k iterations, per-user salt),
  validated against RFC 7914 vectors.
- **Editor**: hosts the parkour debugger with live physics (Jolt bodies, ground probe, avatar
  capsule, dropped balls wire-drawn in-world), WASD/Shift/Space/R/F keyboard control, auto-run
  script, and a "Parkour & Physics" panel (gravity, max step height, physics debug draw) that
  persists options to `project.json`.
- **Hub**: `velocity-hub.exe` — Unity-Hub-style launcher: account gate (sign in / create account),
  sidebar tabs for **Projects** (list, new-project wizard, open in editor / play in demo),
  **Templates** (browse and seed a new project) and **Installs** (persist module toggles).
- **Apps**: editor, demo and hub all support `--project <dir>` / `VELOCITY_PROJECT` and clean
  `--autoquit`/`VELOCITY_AUTOQUIT_MS` shutdown. Demo runs a scripted parkour course headless
  (fixed 120 Hz steps, deterministic) and logs full run telemetry.

## Current phase (see roadmap)

Phases 1-2 (engine bootstrap + movement pipeline), the parkour debugger, the demo game slice,
Jolt-backed physics, the project-driven engine (Project + Auth modules, `--project` in demo and
editor, Parkour & Physics panel) and the Hub launcher + local accounts are **complete**.

## Next steps

1. Full 2D pipeline (orthographic renderer path + 2D sprite/physics support) using the 2D templates.
2. Cloud-backed accounts (identity + sync) while keeping the local AccountManager API.
3. GLTF mesh assets, animation, audio, billboards, light AI.
4. Tilemap/level editor and a first-person controller camera rig for the fps3d template.

## Notes / gotchas (for future sessions)

- shaderc (bgfx 1.19.161, 2026) uses profile names like `s_5_0` (not `vs_5_0`/`ps_5_0`).
- Pass include dirs to shaderc as repeated `-i <dir>` args; a single `-i a b c` silently flattens.
- `BX_PLATFORM_WINDOWS` is **not** defined by bgfx's public headers here — use `_WIN32`.
- In SDL3, `SDL_Event` is a `union` (forward-declare as `union SDL_Event;`).
- bgfx v2026 `Init` uses `swapChain.{nwh,ndt,width,height,numBackBuffers}`; dynamic buffers via
  handle API; `bgfx::reset(flags, &swapChain)` for resize.
- ImGui atlas must be built after `AddFontDefault()` (font added before `GetTexDataAsRGBA32`).
- `Log::init()` must not hold its mutex while calling `log()` (nested lock) — `Log` uses a
  `std::recursive_mutex` to make nested logging safe.
- **bgfx (2026) draws lines via the render-state bit `BGFX_STATE_PT_LINES`, not an index-buffer
  topology parameter.** Index buffers default to 16-bit (`BGFX_BUFFER_INDEX32` = 32-bit).
- **bgfx reserves predefined uniform names** — `u_modelViewProj` is rejected at createUniform
  (assert). Use a custom name (the debug line pass uses `u_debugMvp`).
- Debug bgfx resources must be destroyed before `bgfx::shutdown()` — `DebugDraw::shutdown()`
  releases buffers/uniforms before the renderer shuts down.
- Kinematic landing must only snap to a surface near the feet (`below >= -max_step_height &&`
  `below <= snap_distance`); the old `below <= snap_distance` test also treated a tall box
  overhead as a landing and teleported the body up onto it.
- **Jolt requires a valid `JobSystem`**: pass a `JobSystemSingleThreaded` (Init'd) to `Update` or
  the physics step crashes.
- **Jolt `DestroyBody` asserts on active/in-broadphase bodies**: call `RemoveBody` first.
- **Exclude an observer body from ray casts via a Jolt `BodyFilter`**, never by advancing the ray
  past its AABB — an overshoot restart lands below thin surfaces and breaks ground probes.
- Jolt Factory + type registry are process-lifetime singletons; keep one `PhysicsWorld` instance.