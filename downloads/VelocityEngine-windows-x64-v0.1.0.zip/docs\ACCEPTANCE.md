# ACCEPTANCE — 45-item checklist (core) + engine/Hub phase

Status legend: `[x]` verified green · `[ ]` pending (next phases).

## Build & baseline (1–7)

- [x] **1** Repo configures cleanly via `scripts\configure.bat` (CMake + Ninja + MSVC C++20).
- [x] **2** `scripts\build.bat` builds to `build\bin` (engine libs, tools, apps, tests) in one shot.
- [x] **3** No compiler warnings as errors in engine/editor/demo/test code.
- [x] **4** `velocity-tests.exe` runs green (39 test cases / 207 assertions).
- [x] **5** Deterministic replay: identical `demo` log output across consecutive runs.
- [x] **6** All third-party deps pinned and fetched reproducibly (no system-wide installs).
- [x] **7** Apps log startup/init/shutdown cleanly and exit 0.

## Window & renderer (8–15)

- [x] **8** SDL3 window opens on Windows; `bgfx` D3D11 swap chain bound to it.
- [x] **9** Frame loop: acquire → render views → present; vsync toggle via config.
- [x] **10** Shader pipeline: `.sc` → shaderc (`s_5_0`) → embedded blob → `ShaderLibrary` links programs.
- [x] **11** ImGui overlay renders (atlas, fonts, dynamic vertex buffers) atop the scene view.
- [x] **12** Resize recreates the swap chain without crashes.
- [x] **13** Debug line pass renders via `DebugDraw` (`u_debugMvp` Mat4, `BGFX_STATE_PT_LINES`).
- [x] **14** Clean teardown: `DebugDraw::shutdown()` before `bgfx::shutdown()` (no 0x80000003 at exit).
- [x] **15** Renderer math (perspective/look-at) matches the scene camera.

## Data & configuration (16–20)

- [x] **16** `data/defaults.json` loads from the working directory relative to the executable.
- [x] **17** Config chain: defaults + optional per-project override file.
- [x] **18** Movement tuning is fully data-driven (no hard-coded gameplay numbers in code).
- [x] **19** Live tuning writes back: sliders → `MovementValues` → `Config::write_to`.
- [x] **20** Sanitization clamps/clamps invalid JSON values (no NaNs/infinities propagate).

## Movement model (21–31)

- [x] **21** Walk/run/sprint speeds with smooth acceleration (ground + air).
- [x] **22** Sprint cap 9.50 m/s, run 6.50, walk 4.00 (verified in demo log).
- [x] **23** Gravity, jump speed, and variable-height hold-jump gravity scale.
- [x] **24** Coyote time window allows a late jump after leaving a ledge.
- [x] **25** Jump buffering: a press slightly before landing is consumed on contact.
- [x] **26** Air control caps horizontal speed at `airMaxSpeed` (no drift-forever).
- [x] **27** Max fall speed clamp (no unbounded terminal velocity).
- [x] **28** Auto-step up small obstacles (kerb 0.25 m walked up without a jump).
- [x] **29** Ground snap on descents within `snapDistance` (ledge drop).
- [x] **30** Landing snap is ceiling-safe: never teleports upward onto overhead geometry.
- [x] **31** Deterministic at fixed 120 Hz step; dt clamped worst-case ≤ 0.1 s.

## Parkour debugger (32–38)

- [x] **32** Trail of recent positions drawn in-world, colored by grounded/airborne.
- [x] **33** Velocity arrow + flight-span markers + step-event ticks drawn via `DebugDraw`.
- [x] **34** ImGui HUD: state, position, speeds, coyote/buffer/air timers, frame count.
- [x] **35** Stats panel: peak height, peak speed, distance, flights, air-fraction, leap bests.
- [x] **36** Control: pause / single-step / reset the recorded run.
- [x] **37** Live tuning sliders with immediate controller + JSON feedback.
- [x] **38** `ParkourDebugger` is engine-agnostic (unit-tested without renderer).

## Demo game slice (39–42)

- [x] **39** Scripted course: sprint → 0.25 m kerb auto-step → hold-jump the 0.75 m box.
- [x] **40** Demo logs truthful facts: sprint speed before jump 9.50, kerb step, jump
      clearance (peak 1.71 m, cleared box by 0.96 m), final stats.
- [x] **41** Runs headless, autoquits, exits 0.
- [x] **42** Editor smoke-run (`--autoquit=6000`) logs the parkour run and shuts down cleanly.

## Documentation & acceptance (43–45)

- [x] **43** `README.md` explains the project, build, run, and roadmap.
- [x] **44** `ARCHITECTURE.md` documents modules, data flow, and key systems.
- [x] **45** `DEVELOPMENT_STATUS.md` keeps a live status snapshot; acceptance tracking in this file.

## Next phases (not part of the current acceptance scope)

- Rigid/character physics on Jolt; scenario query; interactive keyboard input;
  GLTF mesh assets + animation; audio; static/dynamic objects; AI/billboard NPCs.

## Engine + Hub phase (completed items)

Status: engine is project-driven; the Hub manages accounts, projects, templates
and installs; parkour + physics options are exposed to every project.

- [x] **46** `Project` engine module: template catalog (`data/templates/*`), installable
      module registry (`data/installs.json`), project create/load/save, module toggles.
- [x] **47** `Auth` engine module: local accounts (sign up / sign in by username or email /
      sign out), PBKDF2-HMAC-SHA256 hashing, persistent accounts + session files, RFC 7914
      KDF vectors verified in unit tests.
- [x] **48** Game templates ship for `blank2d`, `blank3d`, `parkour3d`, `platformer2d`, `fps3d`
      (template.json + seed level.json/movement.json); 2D templates carry an orthographic `mode`.
- [x] **49** `velocity-demo --project <dir>` loads the project's level.json course, movement
      overlay and gravity option; demo stays at parity headless (peak 1.71 m, cleared 0.96 m).
- [x] **50** `velocity-editor --project <dir>` opens the project course + spawn and reads its
      movement overlay.
- [x] **51** Editor "Parkour & Physics" panel: physics gravity, max step height, physics debug
      draw; changes apply live and are persisted to `project.json`.
- [x] **52** Physics ground probe excludes the observer capsule via a Jolt `BodyFilter`
      (editor auto-run stays grounded: peak 1.46 m, 1 flight, 13% air, exit 0).
- [x] **53** `velocity-hub.exe` builds (root option `VELOCITY_BUILD_HUB`); Unity-Hub-style UI:
      account gate + sidebar **Projects / Templates / Installs**.
- [x] **54** Hub Projects: list discovered projects, new-project wizard (name + template),
      open project in the editor (spawns `velocity-editor --project`).
- [x] **55** Hub Templates: browse catalog and seed a new project from any template.
- [x] **56** Hub Installs: toggle + persist bundled/planned module preferences.
- [x] **57** Headless hub smoke (`velocity-hub --smoke --autoquit`): creates the account,
      signs in, computes the project list, scaffolds a project, exits 0.
- [x] **58** Data layout documented; docs/status/acceptance refreshed for the engine + Hub phase.

## Next after this phase

- Full 2D projection/rendering + sprite pipeline (2D templates already configured).
- Cloud account sync (local AccountManager API stays the interface).
- Tilemap/level editor, FPS camera rig, GLTF/animation/audio/AI.