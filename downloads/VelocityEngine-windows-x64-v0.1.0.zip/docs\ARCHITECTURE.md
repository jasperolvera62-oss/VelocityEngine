# ARCHITECTURE

Overview of the engine's structure, key systems and the runtime/data flow.

## Module dependency graph

```
ve_core        (types, logging, config, memory, time, events, project registry,
                account manager — leaf)
   ^
ve_math        (glm helpers, zero deps on engine)
   ^
ve_config      (JSON config chain, serialization)      -> ve_core
   ^
ve_physics     (Jolt-backed world, Course, CharacterController)   -> ve_core
   ^
ve_rendering   (Renderer/bgfx, ShaderLibrary, DebugDraw, ImGui backend)
   ^                       ^
   |                       +--> ve_math (Mat4 helpers), ve_core (log/config)
ve_gameplay    (MovementValues, MovementController, ParkourDebugger)
   ^
ve_serialization (build-time shader embedding, asset glue)      -> ve_config
   ^
Apps: Editor (velocity-editor), Game/DemoGame (velocity-demo), Hub (velocity-hub)
Tests: Catch2 suites link the libs they test.
```

## Engine module map

### Core (`Engine/Core`)
- `Config` — chained JSON config (`data/defaults.json` + optional overrides).
- `Log` — thread-safe (recursive mutex) timestamped logger; tags.
- `Types` — `i8..i64`, `f32`, `f64`, vec/matrix type aliases.
- `Memory` / `Time` / `EventBus` — scaffolding for the later phases.

### Project (`Engine/Project`)
- `ProjectRegistry` — catalog of templates (`data/templates/<id>/template.json`
  with seed files), installable modules (`data/installs.json`), and discovered
  projects (`data/projects/*/project.json`). Creates new projects from a
  template and persists module toggles.
- `default_data_root()` resolves the repo `data/` folder regardless of CWD.
- `Project` struct: name, owner (account), type (2D/3D), template id, plus
  free-form `options` (physics gravity, parkour max step height, ...).

### Auth (`Engine/Auth`)
- `AccountManager` — local accounts: `sign_up` (username, email, password),
  `sign_in` (username or email), `sign_out`, `current_user`, `account_exists`.
  Hashes passwords with PBKDF2-HMAC-SHA256 (60 000 iterations, per-user
  random salt); persists `accounts.json` + `session.json` under the data root.
- `hash_password(password, salt, iterations)` is exposed and matched against
  the RFC 7914 test vectors in unit tests.

### Math (`Engine/Math`)
Thin helpers over GLM: `ve::vec2/vec3/vec4`, `ve::mat4`, `math::look_at`,
`math::perspective`, `math::identity`, conversion helpers, AABB.

### Physics (`Engine/Physics`)
- `PhysicsWorld` — owns a Jolt `PhysicsSystem` (Factory singleton, collision
  layers static/dynamic), a `JobSystemSingleThreaded` for deterministic
  stepping, `add_box`/`add_sphere` rigid bodies, `cast_ray(origin, direction,
  max_distance, ignore_body)` and `ground_height_at(at, max_distance,
  ignore_body)`. The observer-body skip uses a Jolt `BodyFilter` so ray casts
  pass through the avatar without missing surfaces behind it.
- `Course` — `ParkourCourse` geometry (floor, kerb, box) +
  `build_parkour_course` and `load_course_level(project_dir, ...)`.
- `CharacterController` — kinematic capsule avatar (`create`, `teleport`).

### Rendering (`Engine/Rendering`)
- `Renderer` — owns the bgfx device (D3D11, swap chain via SDL3 window),
  view management, clears, reset/resize.
- `ShaderLibrary` — compiles/runtime-loads embedded shader blobs and links
  `Program` handles (e.g. `vs_line` + `fs_line`).
- `DebugDraw` — immediate-mode line/point drawing: `add_line`,
  `add_box_wire`, `add_arrow`, `add_point`, `submit(view, viewProj)`.
  Uses `BGFX_STATE_PT_LINES` for primitive topology and a Mat4 uniform.
- `ImGuiBackend` — ImGui frame init/input/texture atlas, bakes dynamic
  vertices into bgfx dynamic buffers each frame.
- shaders under `Engine/Rendering/Shader/shaders` (`bindings.sc`,
  `vs_cir/fs_cir`, `vs_line/fs_line`, `vs_imgui`).

### Gameplay (`Engine/Gameplay`)
- `MovementValues` — full tuning set (walk/run/sprint speeds, accelerations,
  gravity, jump speed, hold-jump gravity scale, coyote, jump buffer, air
  control, max fall speed, step/snap distances, crouch). Loaded/written as
  JSON keys `movement.*`.
- `MovementController` — kinematic parkour body:
  - fixed-step `step(input, dt)`; dt clamped at 0.1 s worst case
  - horizontal: groundizable velocity blending between grounded max speed and
    air cap; acceleration shaped by ground/air curves
  - vertical: gravity acceleration (scaled while `jump_held`), `jump` sets
    `+jump_speed` when grounded (coyote) or a buffered press exists
  - ground containing function tests a single height (`on_ground`) with
    step-up/step-down auto-snap thresholds; landing is only valid when
    falling and the surface is within `[-max_step_height, snap_distance]`
    (ceiling-safe)
  - exposes a `Snapshot` (position, velocity, move state, air/coyote/buffer
    timers) and `sprint_*`/step counters for debugging.
- `ParkourDebugger` — telemetry recorder (engine-independent):
  - `trail`: ring buffer of per-step `Step` records (pos, horizontal speed,
    ground height, coyote/buffer/air time, move state, frame index)
  - `step_events`: ground-height changes (rise/fall) with delta info
  - `flights`: airborne phases with start/end, distance, peak over start
  - stats: `peak_height`, `max_speed`, `total_distance`, `jump_count`,
    `best_leap_*`, `air_fraction`.

### Serialization & Tools
- `ve_embed` converts compiled `.bin` shaders into a C++ blob table
  (`embedded_shaders.inc`) used by `ShaderLibrary`.

## Runtime flow

The editor loop (`Editor/main.cpp`):

```
SDL3 create window -> bgfx init (swap chain) -> load defaults.json
-> optional --project: load project.json/level.json/movement.json + options
-> per frame:
    poll input                   (or run the parkour script avatar)
    MovementController::step      (fixed 120 Hz, wrapped)
    PhysicsWorld::step            (Jolt, same fixed dt)
    ParkourDebugger::record       (after each step)
    parkour physics render        (course boxes, avatar, balls, trail, arrows, ticks)
    ImGui HUD (stats + Parkour & Physics panel persisted to project.json)
    Renderer::begin_frame -> views: scene + UiView -> end_frame/commit
-> on autoquit or exit: DebugDraw::shutdown() BEFORE renderer.shutdown()
```

The demo (`Game/DemoGame/main.cpp`) is a headless variant: no window, no
ImGui — it advances the same controller at 120 Hz over a scripted (or
project-loaded) course and logs the run (sprint speed, kerb auto-step, box
jump clearance, final stats).

The Hub (`Hub/main.cpp`) is the launcher: render the login/account gate, then
a sidebar workspace (Projects / Templates / Installs) over the ProjectRegistry
and AccountManager. Opening a project spawns `velocity-editor --project ...`.

## Data-driven configuration

`data/defaults.json`:

```json
{
  "engine": { "appName", "window": { "width", "height" } },
  "rendering": { "vsync", "clearColor" },
  "movement": { "walkSpeed", "runSpeed", "sprintSpeed",
                "gravity", "jumpSpeed", "jumpHoldGravityScale",
                "coyoteTime", "jumpBufferTime", "airMaxSpeed",
                "maxStepHeight", "snapDistance", ... }
}
```

A project overlays its own `movement.json` (same keys) on top of the defaults;
`project.json` carries `options` (e.g. `physics.gravity`, `parkour.max_step_height`,
`physics.debug_draw`). The editor's tuning sliders mutate `MovementValues`,
write back through `Config`, and the "Parkour & Physics" panel persists engine
options into the project manifest.

## Data layout (`data/`)

```
defaults.json          global defaults
installs.json          module registry (Installs tab)
templates/<id>/        template.json + seed level.json/movement.json
projects/<name>/       project.json + seeded level/movement
accounts.json, session.json   local accounts + session
```

## Unit test suites (Tests/)

- `test_core` — types, config basics.
- `test_math` — matrix/vector ops.
- `test_config` — JSON chain, overrides, serialization.
- `test_movement` — controller physics: accel curves, jump variants, coyote,
  buffering, air control, snap/auto-step, determinism, ceiling safety.
- `test_parkour_debugger` — recorder fill/cap, stats, step events, flights.
- `test_physics` — Jolt world: bodies, ray cast/ground probe, observer-body
  filter, character remotion.
- `test_project` — template/module scanning, create/load round trip,
  duplicate rejection, install persistence.
- `test_auth` — RFC 7914 KDF vectors, sign-up/sign-in/session persistence,
  validation and duplicate rules.

Run `build\bin\velocity-tests.exe` — 39 test cases, 207 assertions.